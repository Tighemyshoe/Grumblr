<?php


if(isset($_POST['submitaddtopic'])){
	
	require 'addtopic.php';
	/*echo "yourtopicwas submitted";//
	echo $_POST['family'];
	echo$_POST['work'];
	echo $_POST['school'];*/

}

elseif(isset($_POST['submitupdatetopic'])){
	
	require 'changetopic.php';
}


/*elseif(isset($_POST['submitupdatetopic'])){

	header('location: updatetopic.php');
}*/

?>
<!DOCTYPE html>
<html>
<head>
	<title>topic desicison</title>
</head>
<body>
	<h1>YOUR IN TOPIC (topicpage.php)</h1>
	<h3>Add topic </h3>
	<form action="topicpage.php" method="POST" autocomplete="off">	
  		<input type="checkbox" name="family" value="family"> Add family<br>
  		<input type="checkbox" name="work" value="work"> Add work<br>
  		<input type="checkbox" name="school" value="school" checked> Add school<br>
  		<input type="submit" value="Submit" name="submitaddtopic">
	</form>
	

	<!--<form action="topicpage.php" method="POST" autocomplete="off">-->	
		<!--<input type="submit" name="submitaddtopic"  >-->
		
		<!--<button type='submit' name='submitupdatetopic'>CHANGE Existing Topics</button>
	</form> -->
	<!--
	<form>
		
		<button type='submit' name='submitchangetopic'></button>
		<button type='submit' name='submitaddtopic'></button>

	</form>-->

</body>
</html>