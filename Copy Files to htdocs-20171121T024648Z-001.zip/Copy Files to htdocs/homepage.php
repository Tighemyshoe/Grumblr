<?php

	//include 'loginpage.php'; ;<<==IMPORTANT TEST
	//require 'db.php';<<==IMPORTANT TEST
	//include 'logout.php';<<==IMPORTANT TEST 


	//					CONNECTION TEST 				\\
	//$homepagequerytest = $db->query("SELECT * FROM user_information");
	//print_r($homepagequerytest);
	//					CONNECTION TEST 				\\													
?>

<!DOCTYPE html>
<html>
<head>
	<title>HOME PAGE</title>
</head>
<body>
<h1>YOU ARE IN THE HOMe Pahe</h1>
</body>
</html>