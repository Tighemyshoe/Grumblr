<?php 
require 'db.php';
//<!---The code commented out directly below checks to see if connected to the database and can query it --->
//<----$result = $db->query("SELECT * FROM user_information WHERE user_name='karlbenoit'");
//print_r($result);    ----->//
if(isset($_POST['submit'])){
	require'login.php';
	//header("location: homepage.php");
}



?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h1>
		<form  action='loginpage.php' method="POST" autocomplete="off">
			User Name: <input type="text" name="user"></br>
			Password: <input type="text" name="pass"></br>
			<button type="submit" name='submit'>Login Now!!!!!</button>
		</form>


	</h1>

</body>
</html>