<?php
//echo"at lest your at the page";
$dbhost='localhost';
$dbname='Grumblr';
$dbuser='root';
$dbpass='root';

$db = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

// Check connection
/*if (mysqli_connect_errno())
 {
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }else{echo"your in the db";}*/




?>