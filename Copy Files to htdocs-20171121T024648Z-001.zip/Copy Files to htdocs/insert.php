<?php
require 'db.php';
ob_start();
session_start();
//echo"your in insert.php";
//$invitingname= $_SESSION['inviting_user'];
//$invitedname= $_SESSION['invited_user'];
$chatid = $_SESSION['chatid'];
/*/echo "hello";

$uname = $_SESSION['login'];
//echo $chatid;
$msg = $_POST['msg'];



///<!-- GET MESSAGE ID's /// 
$prevQuery= $db->query(" SELECT * FROM chat_messages WHERE chat_id='$chat_id' ");
$prevResult= $prevQuery->fetch_assoc();
$prevMeg= $prevResult['message_id'];
print_r($prevResult);
///<!-- GET MESSAGE ID's /// 

///<!-- GET USER ID's /// 
$idquery = $db->query("SELECT user_id FROM user_information WHERE user_name='$uname' ");
$idresult = $idquery->fetch_assoc();
$id= $idresult['user_id'];
///<!-- GET USER ID's /// 

///<!-- GET SET AND GET MESSAHES FROM TABLE CHAT_MESSAGES /// 
$intochat = $db->query("INSERT INTO chat_messages (user_name, message,user_id,chat_id) VALUES ('$uname', '$msg','$id','$chatid')");*/
$fromchat = $db->query("SELECT * FROM chat_messages WHERE chat_id='$chatid' ORDER BY chat_id ASC");
//$chatresult = $fromchat->fetch_assoc();
///<!-- GET SET AND GET MESSAHES FROM TABLE CHAT_MESSAGES /// 
//print_r($chatresult);
//while($chatresult = $fromchat->fetch_assoc()){
	//if(isset($_SESSION['msg']) && )
	//header('location: charoom.php');
	
	
	
while($chatresult = $fromchat->fetch_assoc()){
			//unset($_POST['msg']);
		//header('location: charoom.php');
	echo $chatresult['chat_id'].":".$chatresult['user_name'].": ".$chatresult['message']."<br>";
		//unset($_POST['msg']);
		//header('location: chatroom.php');
		//unset($_POST['msg']);
	}

	
	

//}

/*foreach ($chatresult as $key => $value) {
	echo $key.": ".$value."<br>";
	//echo"is for loop working";
	//foreach ($variable as $key => $value) {
		# code...
	}*/


	# code...



/*
while($chatresult = $fromchat->fetch_assoc()) {
	//echo "hello"."<br>";
	echo $chatresult['user_name'].": ".$chatresult['message'] ."<br>";
	//echo"<\br>";
}*/
?>