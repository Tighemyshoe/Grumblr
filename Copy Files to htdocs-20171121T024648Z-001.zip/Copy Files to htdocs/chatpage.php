<?php

if(isset($_POST['submitcode'])){

	require 'connectchat.php';
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action='chatpage.php' method="POST" autocomplete="off">
	Input your code!: <input type="text" name="chatcode">
	<button type='submit' name='submitcode'> Submit Code</button>

</form>


</body>
</html>