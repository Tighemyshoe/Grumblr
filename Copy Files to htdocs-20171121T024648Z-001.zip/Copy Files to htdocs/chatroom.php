<html>
<head>
<title>Chat Box</title>


</head>
<body>
<form action='chatroom.php' method="POST" autocomplete="off">

Your Message: <input type="text" name="msg" /> <br />
<button type="submit" name="submitmsg">Submit msg</button>
</form>
<textarea rows='20' cols='50'>
	
	
</textarea><br />
<?php 
	require 'db.php';
	session_start();
	//if(!isset($_SESSION['chatid'])){echo "the session is not set";}

	$username = $_SESSION['login'];
	$chatid = $_SESSION['chatid'];

	//echo $chatid."<br>";
	//echo $username."<br>";

	if(isset($_POST['submitmsg'])){
	$msg=$_POST['msg'];
	//unset($_POST['msg']);
		if(isset($_POST['msg'])){
			echo $msg."<br>";
			$chatinsert= $db->query("INSERT INTO chat_messages (user_name, message,chat_id) VALUES ('$username', '$msg','$chatid')");
			unset($_POST['msg']);
			if(!isset($_POST['msg'])){
				echo"resubmit form"."<br>";
			}
		}
	//echo "message: ".$msg."<br>";
	//header('location: chatroom.php');
	
}

	//$chatuser= $db->query("INSERT INTO chat_messages (user_name, message,chat_id) VALUES ('$username', '$msg','$chatid')");
	
	//$chatquery=$db->query("SELECT message FROM chat_messages WHERE chat_id='$chatid' ORDER BY message_id DESC LIMIT 7");
	//if(isset($_POST['submitmsg'])){
		//header('location: chatroom.php');
		//exit;
		//isset($_POST['submitmsg'])){
		//header('location: chatroom.php');

	/*while($chatresult= $chatquery->fetch_assoc()){

		echo $chatresult['message']."<br>";


	}*/
	//while

	$chatquery=$db->query("SELECT * FROM chat_messages WHERE chat_id='$chatid' ORDER BY message_id DESC LIMIT 7");
	while($chatreuslt=$chatquery->fetch_assoc()){
		echo $chatreuslt['user_name'].": ".$chatreuslt['message']."<br>";

	}
	//}


//}
	//print_r($chatquery);
	//echo"<br>";
//$_SESSION['msg'] = $_POST['msg'];
/*if(isset($_POST['submitmsg'])){

	$idquery = $db->query("SELECT user_id FROM user_information WHERE user_name='$username' ");
	$idresult = $idquery->fetch_assoc();
	$id= $idresult['user_id'];

	if($db->query("INSERT INTO chat_messages (user_name, message,user_id,chat_id) VALUES ('$username', '$msg','$id','$chatid')")){

		
		$chatresult = $chatquery->fetch_assoc();
		print_r($chatresult);
		foreach ($chatresult as $key => $value) {
			# code...
		
		echo $key.": ".$value."<br>";
		}
	}

	}*/

?>


</body>