<?php
require'db.php';

if(isset($_POST['registersubmit'])){
	//echo"form sent";
	require 'register.php';

}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<h1>
		<form  action='registerpage.php' method="POST" autocomplete="off">
			Create User Name: <input type="text" name="newuser"></br>
			Set Password: <input type="text" name="setpass"></br>
			<button type="submit" name='registersubmit'>Register Now!!!!!</button>
		</form>


	</h1>

</body>
</html>