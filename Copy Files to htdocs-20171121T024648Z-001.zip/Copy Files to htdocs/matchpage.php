<?php

if(isset($_POST['submit'])){
	if(isset($_POST['user_sug'])){
	require 'suggestedmatches.php';}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Matches!! (matchpage.php)</title>
</head>
<body>

	<form action='matchpage.php'  method='POST' autocomplete='off'>

  		<input type="checkbox"  name="user_sug" vaule='suggested'> See suggested Users<br>
  		<input type="checkbox" name="topic_sug" value="topics"> See Users suggested by Topic<br>
	<button type="submit"  name="submit">Submit</button>>
	</form>

</body>
</html>