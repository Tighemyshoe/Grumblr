<?php

require 'db.php';
session_start();


$username = $_SESSION['login'];
//echo $username;
$invitequery= $db->query("SELECT user_inviting, invite_code, chat_name FROM invite WHERE user_invited='$username' " );


while($inviteresult= $invitequery->fetch_assoc()){
	//echo"nothigns here";
	$userinviting = $inviteresult['user_inviting'];
	echo "Person inviting you: ".$inviteresult['user_inviting']."</br>";
	echo "Their invite Code: ".$inviteresult['invite_code']."</br>";
	$checkagain = $db->query("SELECT * FROM user_information WHERE user_name='$userinviting' ");
	$checkresult= $checkagain->fetch_assoc();
	$actvity = $checkresult['active'];
	if($actvity!=1){
		echo"User isn't currently active"."</br>";

	}else{
		echo"That user is active click here to go to chatroom";
		echo "<a href='chatroom.php'>CHATROOM</a></br>";
		
	}

}


//echo: 

//echo

?>