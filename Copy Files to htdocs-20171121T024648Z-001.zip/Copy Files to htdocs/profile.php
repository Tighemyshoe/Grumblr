<?php
session_start();
ob_start();
	/*if(isset($_SESSION['login'])){
		//echo"welcome: ".$_SESSION['login'];
	}
	else{
		echo"you cannot access since your not logged in";
		//header('location: loginpage.php');
		//die();
	//	header('location: loginpage.php');
	}*/
	if(isset($_POST['sendinvite']))
	{
		require 'sendinvite.php';
	}
?>

<?php
//require'db.php';
//$var = "user_information.user_name"
//$work=mysqli_real_escape_string($db, $var)


//$query=$db->query("SELECT user_information.
//	)" );

//$result= $query->fetch_assoc();
//print_r($result);
//echo $result['user_name'];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>YOUR IN THE PROFILE PAGE</h1>
	<a href="logout.php">Click Here to Logout</a>
	<a href="topicpage.php">Click Here to See and Update Topics</a>
	<a href="matchpage.php">Click Here to See Your Matches</a>
	<a href="invites.php">Check Your Invites!!</a>

	<form action='profile.php' method="POST" autocomplete="off">
		Invite User: <input type="text" name="invitname"></br>
		Name Your ChatRoom <input type="text" name="chatname">
		Chat Code: <input type="text" name="chatcode"></br>
		<button type='submit' name='sendinvite'>Send Invite</button>
	</form>


</body>
</html>

