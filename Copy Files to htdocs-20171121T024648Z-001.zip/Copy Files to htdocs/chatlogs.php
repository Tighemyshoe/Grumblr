<?php 

require 'db.php'


?>