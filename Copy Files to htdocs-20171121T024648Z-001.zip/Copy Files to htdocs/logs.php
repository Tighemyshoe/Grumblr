<?php
require 'db.php'
//$con = mysql_connect('localhost','root','');
//mysql_select_db('chatbox', $con);

$result1 = $db->query("SELECT * FROM logs ORDER BY id DESC");

while($extract = mysql_fetch_array($result1)) {
	echo "<span>" . $extract['user_name'] . "</span>: <span>" . $extract['message'] . "</span><br />";
}
?>